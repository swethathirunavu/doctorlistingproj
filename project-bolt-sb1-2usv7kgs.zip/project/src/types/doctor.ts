export interface Doctor {
  id: string;
  name: string;
  specialty: string[];
  consultationType: string[];
  experience: number;
  fees: number;
  rating: number;
  image: string;
  availability: string[];
}

export interface FilterState {
  searchTerm: string;
  consultationType: string;
  specialties: string[];
  sortBy: 'fees' | 'experience' | '';
  sortOrder: 'asc' | 'desc';
}

export interface AppointmentFormData {
  date: string;
  time: string;
  type: string;
  notes: string;
}

export interface Appointment extends AppointmentFormData {
  id: string;
  doctorId: string;
  doctorName: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  createdAt: string;
}